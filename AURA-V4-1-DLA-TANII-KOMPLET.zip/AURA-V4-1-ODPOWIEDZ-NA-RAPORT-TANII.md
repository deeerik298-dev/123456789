# AURA INTERIUM V4.1 — poprawki po kontroli Tanii

Data: 11.10.2026. Zmiana wyłącznie oznaczeń wersji i daty w projektach polityk prywatności NL/EN oraz dokumentacji. Strony główne, CSS, JavaScript, zdjęcia i backend są bajtowo niezmienione względem V4. Identyfikator bazowej strony pozostaje AURA-V4-20261010-01; rewizja paczki: V4.1-20261011-privacy.

1. Potwierdzono uwagę P2: w dwóch politykach były stare oznaczenia v3. Zastąpiono je V4, datę aktualizacji szkicu ustawiono na 11 października 2026. Sprawdzono oba HTML i brak pozostałości v3.
2. Polityki nadal są szkicami, z widocznym CONCEPT/DRAFT i brakującymi danymi. Nie wymyślono danych administratora, retencji ani ustaleń z dostawcami. Ten punkt nie jest rozwiązany bez danych/akceptacji właściciela.
3. SHA256 oryginalnej V4 zgłoszony przez Tanię zgadza się z ponownie obliczoną sumą i istniejącym zewnętrznym AURA-V4-SUMY-KONTROLNE.json: 1a0b22824108bcd4e97f2ff11dd10e42d1db5047a815e1cb4dd1a3af10c05f6c. Osobny plik nie był wcześniej dostarczony Tanii; teraz jest dołączony do pakietu przekazania razem z osobnym manifestem nowej V4.1.
4. Niezależne testy dynamiczne Tanii pozostają do wykonania. Dotychczasowych zrzutów i testów Kalinki nie przedstawia się jako testów Tanii. Testów całej przeglądarki nie powtarzano przy zmianie samego tekstu dwóch szkiców; wykazano bajtową zgodność stron głównych/CSS/JS/obrazów/backendu z przetestowaną V4. Nowe teksty polityk sprawdzono statycznie.

Nie publikowano zmian i nie wysyłano wiadomości. Rekomendacja: przekazać V4.1 do dalszej kontroli, nie zatwierdzać jeszcze publikacji. W pakiecie przekazania znajduje się nowy ZIP, zewnętrzny manifest tej paczki, oryginalny manifest V4 i niniejsza odpowiedź na raport.
